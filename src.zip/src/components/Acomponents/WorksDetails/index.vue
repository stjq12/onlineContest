<template>
  <div class="app-container">
    <!-- 弹出作品框 -->
    <el-dialog title="作品详情" :visible.sync="dialogFormVisible" width="60%" @close="closeDialog">
      <el-tabs>
        <el-tab-pane label="作品基本信息">
          <table class="mailTable" cellspacing="0" cellpadding="0">
            <tr>
              <td class="column"> 作品名称：</td>
              <td>{{ WorksDetails.worksList.worksname }}</td>
            </tr>
            <tr>
              <td class="column"> 团队名字：</td>
              <td>{{ WorksDetails.worksList.teamname }}</td>
            </tr>
            <tr>
              <td class="column"> 团队成员：</td>
              <td>
                <span v-for="(item, index) in WorksDetails.authorList" :key="index" style="margin-right: 20px">
                  {{ item }}
                </span>
              </td>
            </tr>
            <tr>
              <td class="column"> 学校：</td>
              <td>{{ WorksDetails.worksList.school }}</td>
            </tr>
            <tr>
              <td class="column">  作品指导老师：</td>
              <td> {{ WorksDetails.worksList.teacher }}</td>
            </tr>
            <tr>
              <td class="column">  指导老师单位：</td>
              <td> {{ WorksDetails.worksList.unit }}</td>
            </tr>
            <tr>
              <td class="column">  作品简介：</td>
              <td> {{ WorksDetails.worksList.introduce }}</td>
            </tr>
            <tr>
              <td class="column">   作品类型：</td>
              <td>{{ WorksDetails.worksList.type }}</td>
            </tr>
          </table>
        </el-tab-pane>
        <el-tab-pane label="作品设计思路">
          <table class="mailTable" cellspacing="0" cellpadding="0">
            <tr>
              <td class="column">  作品设计思路：</td>
              <td> {{ WorksDetails.worksList.design }}</td>
            </tr>
          </table>
        </el-tab-pane>
        <el-tab-pane label="作品图片展示">
          <div class="details-item">
            <a :href="pdf" target="_blank">点击预览作品ppt</a>
          </div><br>
          <div class="details-item">
            作品展示：
          </div>
          <el-image v-for="(url, index) in WorksDetails.imageList" :key="index" style="width: 80%; height: 60%" :src="url" />
        </el-tab-pane>
        <el-tab-pane label="作品演示">
          <div class="details-item">
            视频观赏：
          </div>
          <video ref="videoClose" :src="video" controls class="video" width="100%" />
        </el-tab-pane>
        <el-tab-pane label="作品评价">
          <div v-if="WorksDetails.scoreList">
            <table class="mailTable" cellspacing="0" cellpadding="0">
              <tr>
                <td class="column">
                  <div v-for="item in WorksDetails.scoreList" :key="item" class="details-item">
                    评委： {{ item.judge }}
                  </div>
                </td>
                <td>
                  <div v-for="item in WorksDetails.scoreList" :key="item" class="details-item">
                    <span style="margin-left: 100px">评分： {{ item.score }}</span>
                  </div>
                </td>
              </tr>
            </table>
          </div>
          <div class="details-item">
            <h3>总得分：{{ WorksDetails.worksList.score }}</h3>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </div>
</template>

<script>
import { getWorkDetails } from '@/api/common'

export default {
  name: 'WorkDetails',
  data() {
    return {
      dialogFormVisible: false,
      WorksDetails: {
        authorList: [],
        worksList: {
          worksname: '',
          introduce: '',
          design: '',
          date: '',
          teacher: '',
          unit: '',
          teamname: '',
          match_project: '',
          match_name: '',
          video: '',
          score: '',
          type: '',
          document: '',
          pdf: ''
        },
        imageList: [],
        scoreList: []
      }
    }
  },
  computed: {
    video: {
      get() {
        return 'https://sd.bnuz.edu.cn/' + this.WorksDetails.worksList.video
      }
    },
    pdf: {
      get() {
        return 'https://sd.bnuz.edu.cn/' + this.WorksDetails.worksList.pdf
      }
    }
  },
  methods: {
    popWorkDetails(wid) {
      getWorkDetails(wid).then(response => {
        this.dialogFormVisible = true
        this.WorksDetails = response.obj
        this.getImg()
      })
    },
    closeDialog() {
      this.$refs.videoClose.pause()
    },
    getImg() {
      for (var i = 0; i < this.WorksDetails.imageList.length; i++) {
        this.WorksDetails.imageList[i] = 'https://sd.bnuz.edu.cn/' + this.WorksDetails.imageList[i]
      }
    }
  }
}
</script>
<style scoped>
  .details-item {
    font-size: 18px;
    margin-bottom: 20px;
  }
  .mailTable{
    width: 100%;
    border-top: 1px solid #E6EAEE;
    border-left: 1px solid #E6EAEE;
}
.mailTable tr td{
    width: 200px;
    height: 50px;
    line-height: 25px;
    box-sizing: border-box;
    padding: 0 10px;
    border-bottom: 1px solid #E6EAEE;
    border-right: 1px solid #E6EAEE;
}
.mailTable tr td.column {
    background-color: #EFF3F6;
    color: #393C3E;
    width: 15%;
}
</style>
